﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio5 : Form
    {
        double limiteInferior = 0, limiteSuperior = 0;    

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
        }

        private void txtPalavra1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPalavra1_Click(object sender, EventArgs e)
        {

        }

        private void lblPalavra2_Click(object sender, EventArgs e)
        {

        }

        private void txtPalavra2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random random = new Random();

            double resultado = random.NextDouble() * (limiteSuperior -  limiteInferior) + limiteInferior;
            string resultadoFormatado = resultado.ToString("F2");
            MessageBox.Show("Numero sorteado: " + resultadoFormatado);
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out limiteSuperior))
            {
                MessageBox.Show("Entrada inválida");
                limiteSuperior = 0;                
            }
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out limiteInferior))
            {
                MessageBox.Show("Entrada inválida");
                limiteInferior = 0;               
            }
        }
    }
}
