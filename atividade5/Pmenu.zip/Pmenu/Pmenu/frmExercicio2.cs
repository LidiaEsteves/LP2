﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            if(palavra1.Equals(palavra2))
                MessageBox.Show($"Palavra 1 é igual a Palvra 2");
            else
            {
                MessageBox.Show($"Palavra 1 não é igual a Palvra 2");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;
            int tamanho = (txtPalavra2.Text.Length)/2;
            string resultado = palavra2.Insert(tamanho, palavra1);

            MessageBox.Show("Resultado: " +resultado);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            txtPalavra1.Text = palavra1 + "**";
            txtPalavra2.Text = palavra2 + "**";

            
        }

        private void lblPalavra1_Click(object sender, EventArgs e)
        {

        }

        private void lblPalavra2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txtPalavra2.Clear();
            txtPalavra1.Clear(); 
        }
    }
}
