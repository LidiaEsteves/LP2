﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtladoB_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(txtladoB.Text, out ladoB))
            {
                MessageBox.Show("erro");
                e.Cancel = true;
            }
        }

        private void txtladoC_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(txtladoC.Text, out ladoC))
            {
                MessageBox.Show("erro");
                e.Cancel = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((ladoA < ladoB + ladoC) && (ladoA > Math.Abs(ladoB - ladoC)) &&
                 (ladoB < ladoA + ladoC) && (ladoB > Math.Abs(ladoA - ladoC)) &&
                 (ladoC < ladoA + ladoB) && (ladoC > Math.Abs(ladoA - ladoB)))
            {
                if ((ladoA == ladoB) && (ladoA == ladoC))
                    MessageBox.Show("Equilátero");
                else if ((ladoA == ladoB) || (ladoB == ladoC))
                    MessageBox.Show("Isósceles");
                else
                    MessageBox.Show("Escaleno");


            }
            else
                MessageBox.Show("Não forma triângulo");
        }

        private void txtladoA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtladoA.Text,out ladoA))
            {
                MessageBox.Show("erro");
                e.Cancel = true;
            }
        }
    }
}
