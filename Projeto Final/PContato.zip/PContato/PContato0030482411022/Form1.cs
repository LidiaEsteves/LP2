﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482411022
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
           
            try
            {
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=BD;User ID=BD2411013;Password=G@bi2000");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atribuir banco de dados"+ex.Message);

            }

        }

        private void cadastroContatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["fmrContato"];
            if (fc != null) //se encontrou (for verdadeiro), fecha
                fc.Close();

            frmContato FRMC = new frmContato();
            FRMC.MdiParent= this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sobre tela = new sobre();
            tela.Show();
        }
    }
}
